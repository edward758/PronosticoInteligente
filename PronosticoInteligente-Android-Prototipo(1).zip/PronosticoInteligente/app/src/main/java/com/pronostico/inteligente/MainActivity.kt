package com.pronostico.inteligente

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Match(
    val home: String,
    val away: String,
    val league: String,
    val homeGoalsAvg: Double,
    val awayGoalsAvg: Double,
    val homeCornersAvg: Double,
    val awayCornersAvg: Double,
    val homeCardsAvg: Double,
    val awayCardsAvg: Double,
    val homeShotsOnTargetAvg: Double,
    val awayShotsOnTargetAvg: Double
)

private val demoMatches = listOf(
    Match("Cóndores FC", "Atlético Río", "Liga de ejemplo", 1.8, 1.1, 5.4, 4.1, 2.1, 2.5, 5.2, 3.8),
    Match("Deportivo Valle", "Unión Central", "Liga de ejemplo", 1.2, 1.3, 4.2, 5.0, 2.8, 2.0, 3.9, 4.4),
    Match("Real Montaña", "Puerto Azul", "Liga de ejemplo", 2.0, 0.8, 6.1, 3.7, 1.7, 2.9, 6.0, 2.8),
    Match("Estrella Sur", "Norte Unido", "Liga de ejemplo", 1.4, 1.5, 4.8, 4.6, 2.4, 2.2, 4.3, 4.6)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    PredictionApp()
                }
            }
        }
    }
}

@Composable
fun PredictionApp() {
    var selectedMarket by remember { mutableStateOf("Resumen") }
    var selectedMatch by remember { mutableStateOf<Match?>(null) }

    val markets = listOf("Resumen", "Goles", "Ambos marcan", "Córners", "Tarjetas", "Tiros a puerta", "Ganador")

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp)
    ) {
        Text("⚽ Pronóstico Inteligente", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("Prototipo 0.1 • estadísticas de demostración", color = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { selectedMatch = null }) { Text("Partidos") }
            OutlinedButton(onClick = { selectedMarket = "Historial" }) { Text("Historial") }
        }
        Spacer(Modifier.height(12.dp))

        if (selectedMarket != "Historial") {
            Text("Mercados", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(markets) { market ->
                    FilterChip(
                        selected = selectedMarket == market,
                        onClick = { selectedMarket = market },
                        label = { Text(market) }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (selectedMarket == "Historial") {
            HistoryScreen(onBack = { selectedMarket = "Resumen" })
        } else if (selectedMatch != null) {
            MatchDetail(match = selectedMatch!!, market = selectedMarket, onBack = { selectedMatch = null })
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(demoMatches) { match ->
                    MatchCard(match = match, market = selectedMarket, onClick = { selectedMatch = match })
                }
            }
        }
    }
}

@Composable
fun MatchCard(match: Match, market: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(match.league, color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text("${match.home}  vs  ${match.away}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Text(predictionText(match, market), fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text("Datos ficticios para probar la aplicación", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onClick) { Text("Ver análisis") }
        }
    }
}

@Composable
fun MatchDetail(match: Match, market: String, onBack: () -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            OutlinedButton(onClick = onBack) { Text("← Volver") }
            Spacer(Modifier.height(8.dp))
            Text("${match.home} vs ${match.away}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Competición: ${match.league}")
            Spacer(Modifier.height(12.dp))
            Text("Análisis: $market", fontWeight = FontWeight.Bold)
            Text(predictionText(match, market), fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Text("Promedios usados (datos de demostración)", fontWeight = FontWeight.SemiBold)
        }
        item { StatLine("Goles por partido", match.homeGoalsAvg, match.awayGoalsAvg) }
        item { StatLine("Córners por partido", match.homeCornersAvg, match.awayCornersAvg) }
        item { StatLine("Tarjetas por partido", match.homeCardsAvg, match.awayCardsAvg) }
        item { StatLine("Tiros a puerta por partido", match.homeShotsOnTargetAvg, match.awayShotsOnTargetAvg) }
        item {
            Spacer(Modifier.height(8.dp))
            Text(
                "Este cálculo es ilustrativo. Todavía no usa datos reales, forma reciente, alineaciones ni una fuente deportiva conectada.",
                color = MaterialTheme.colorScheme.secondary
            )
        }
    }
}

@Composable
fun StatLine(label: String, home: Double, away: Double) {
    Card {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f)) {
                Text(label, fontWeight = FontWeight.Medium)
                Text("Local: %.1f  •  Visitante: %.1f".format(home, away))
            }
        }
    }
}

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Historial de pronósticos", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Todavía no hay pronósticos reales guardados. En la siguiente fase registraremos cada predicción antes del partido y compararemos el resultado final.")
        OutlinedButton(onClick = onBack) { Text("Volver a partidos") }
    }
}

fun predictionText(match: Match, market: String): String {
    val totalGoals = match.homeGoalsAvg + match.awayGoalsAvg
    val totalCorners = match.homeCornersAvg + match.awayCornersAvg
    val totalCards = match.homeCardsAvg + match.awayCardsAvg
    val totalShots = match.homeShotsOnTargetAvg + match.awayShotsOnTargetAvg

    return when (market) {
        "Goles" -> "Promedio combinado: %.1f goles • Más de 1.5: %s".format(
            totalGoals,
            if (totalGoals >= 2.4) "señal favorable en esta demo" else "señal moderada en esta demo"
        )
        "Ambos marcan" -> if (match.homeGoalsAvg >= 1.0 && match.awayGoalsAvg >= 1.0)
            "Ambos promedian al menos 1 gol (demo)" else "Uno de los promedios es inferior a 1 gol (demo)"
        "Córners" -> "Promedio combinado: %.1f córners".format(totalCorners)
        "Tarjetas" -> "Promedio combinado: %.1f tarjetas".format(totalCards)
        "Tiros a puerta" -> "Promedio combinado: %.1f tiros a puerta".format(totalShots)
        "Ganador" -> when {
            match.homeGoalsAvg > match.awayGoalsAvg + 0.25 -> "La demo favorece al local por promedio de goles"
            match.awayGoalsAvg > match.homeGoalsAvg + 0.25 -> "La demo favorece al visitante por promedio de goles"
            else -> "Promedios cercanos: partido equilibrado en esta demo"
        }
        else -> "Goles: %.1f • Córners: %.1f • Tarjetas: %.1f".format(totalGoals, totalCorners, totalCards)
    }
}
