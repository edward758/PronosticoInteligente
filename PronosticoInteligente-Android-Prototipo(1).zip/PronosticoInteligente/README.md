# Pronóstico Inteligente — prototipo Android

Primera versión educativa para Android con Kotlin y Jetpack Compose.
Incluye partidos ficticios, cálculo ilustrativo de probabilidades y filtros básicos.
No usa datos deportivos en vivo todavía.

## Requisitos
- Android Studio reciente
- JDK incluido con Android Studio
- Android SDK instalado desde SDK Manager

## Cómo abrir
1. Descomprime el ZIP.
2. Android Studio > Open y selecciona la carpeta `PronosticoInteligente`.
3. Espera a que termine Gradle Sync.
4. Si Android Studio pide actualizar Gradle/Android Gradle Plugin, acepta la combinación compatible que sugiera el IDE.
5. Crea un emulador desde Device Manager o conecta tu Android con Depuración USB.
6. Pulsa Run ▶.

## Nota
Este proyecto es un punto de partida. Si la versión de Android Gradle Plugin que tengas instalada no acepta las versiones indicadas, usa la actualización sugerida por Android Studio. Las probabilidades son demostrativas y no constituyen asesoría de apuestas.
